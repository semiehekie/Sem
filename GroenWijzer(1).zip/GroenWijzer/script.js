async function loadICalendarFromURL(url) {
    try {
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP fout! Status: ${response.status}`);
        }
        const icalData = await response.text();
        parseICalendar(icalData);
    } catch (error) {
        console.error("Fout bij het ophalen van iCalendar:", error);
    }
}

function parseICalendar(data) {
    const events = [];
    const lines = data.split(/\r?\n/);
    let event = {};

    lines.forEach(line => {
        if (line.startsWith("BEGIN:VEVENT")) {
            event = {};
        } else if (line.startsWith("END:VEVENT")) {
            events.push(event);
        } else if (line.startsWith("SUMMARY:")) {
            event.summary = line.replace("SUMMARY:", "").trim();
            // We splitsen de samenvatting: vak - klas - extra info
            const parts = event.summary.split(" - ");
            if (parts.length >= 3) {
                event.subject = parts[0]; // Vaknaam (bijv. Nederlands)
                event.classNumber = parts[1].replace(/h\d+/g, '').trim(); // Verwijder de klasnaam (zoals h2hv1)
                event.additionalInfo = parts[2]; // Extra informatie (zoals wtr)
            } else {
                event.subject = parts[0]; // Als de samenvatting geen extra info heeft, neem gewoon het vak
                event.classNumber = parts[1] || ''; // Nummer zoals 109
                event.additionalInfo = ''; // Geen extra info
            }
        } else if (line.startsWith("DTSTART:")) {
            event.start = line.replace("DTSTART:", "");
        } else if (line.startsWith("DTEND:")) {
            event.end = line.replace("DTEND:", "");
        }
    });

    const filteredEvents = filterEventsByCurrentWeek(events);
    displayEvents(filteredEvents);
}

function filterEventsByCurrentWeek(events) {
    const currentDate = new Date();
    const startOfWeek = getStartOfWeek(currentDate);
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);

    return events.filter(event => {
        if (!event.start) return false;
        const eventStartDate = new Date(convertICalDateToISO(event.start));
        return (eventStartDate >= startOfWeek && eventStartDate <= endOfWeek);
    });
}

function getStartOfWeek(date) {
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1);
    const startOfWeek = new Date(date);
    startOfWeek.setDate(diff);
    startOfWeek.setHours(0, 0, 0, 0);
    return startOfWeek;
}

function formatHour(hour, minute) {
    const h = hour < 10 ? "0" + hour : hour;
    const m = minute < 10 ? "0" + minute : minute;
    return h + ":" + m;
}

function convertICalDateToISO(icalString) {
    const year = icalString.substring(0, 4);
    const month = icalString.substring(4, 6);
    const day = icalString.substring(6, 8);
    let time = "00:00:00";
    if (icalString.indexOf("T") > -1) {
        const hour = icalString.substring(9, 11);
        const minute = icalString.substring(11, 13);
        const second = icalString.substring(13, 15);
        time = `${hour}:${minute}:${second}`;
    }

    if (icalString.endsWith("Z")) {
        return `${year}-${month}-${day}T${time}Z`;
    } else {
        return `${year}-${month}-${day}T${time}`;
    }
}

function displayEvents(events) {
    const eventTable = document.getElementById("eventTable");
    eventTable.innerHTML = "";

    const startHour = 8;
    const endHour = 20;
    const slotDuration = 30;
    const aantalSlots = (endHour - startHour) * 2;

    const days = ["Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag"];

    for (let i = 0; i < aantalSlots; i++) {
        const slotStartTotalMinutes = startHour * 60 + i * slotDuration;
        const slotEndTotalMinutes = slotStartTotalMinutes + slotDuration;
        const slotStartHour = Math.floor(slotStartTotalMinutes / 60);
        const slotStartMinute = slotStartTotalMinutes % 60;
        const slotEndHour = Math.floor(slotEndTotalMinutes / 60);
        const slotEndMinute = slotEndTotalMinutes % 60;

        const row = document.createElement("tr");

        const timeCell = document.createElement("td");
        timeCell.classList.add("tijdkolom");
        timeCell.textContent = formatHour(slotStartHour, slotStartMinute) + " - " + formatHour(slotEndHour, slotEndMinute);
        row.appendChild(timeCell);

        days.forEach((dag, index) => {
            const dayCell = document.createElement("td");

            const eventForSlot = events.find(e => {
                if (!e.start) return false;
                const isoStart = convertICalDateToISO(e.start);
                const eventDate = new Date(isoStart);

                const eventTotalMinutes = eventDate.getHours() * 60 + eventDate.getMinutes();
                if (eventTotalMinutes < slotStartTotalMinutes || eventTotalMinutes >= slotEndTotalMinutes) return false;

                if (eventDate.getDay() !== index + 1) return false;

                return true;
            });

            if (eventForSlot) {
                // Weergeef alleen vak en nummer + extra info zonder klasnaam
                dayCell.textContent = `${eventForSlot.subject} ${eventForSlot.classNumber} ${eventForSlot.additionalInfo}`;
            } else {
                dayCell.textContent = "";
                dayCell.classList.add("empty-slot");
            }
            row.appendChild(dayCell);
        });

        eventTable.appendChild(row);
    }
}

// Vervang deze URL met je eigen iCalendar-link
const icalURL = "";

// Laad de kalender bij het starten van de pagina
loadICalendarFromURL(icalURL);

// Vernieuw de kalender elke minuut
//setInterval(() => {
//    console.log("Vernieuwen iCalendar...");
//    loadICalendarFromURL(icalURL);
//}, 600000); // 60.000 ms = 1 minuut

document.addEventListener("DOMContentLoaded", () => {
    const toggleNotesButton = document.createElement("button");
    toggleNotesButton.textContent = "Toon/verberg notities";
    toggleNotesButton.addEventListener("click", toggleNotesVisibility);
    document.body.appendChild(toggleNotesButton);

    clearNotesOnNewWeek();
});

function displayEvents(events) {
    const eventTable = document.getElementById("eventTable");
    eventTable.innerHTML = "";

    const startHour = 8;
    const endHour = 20;
    const slotDuration = 30;
    const aantalSlots = (endHour - startHour) * 2;
    const days = ["Maandag", "Dinsdag", "Woensdag", "Donderdag", "Vrijdag"];
    const notesEnabled = getNotesVisibility();

    for (let i = 0; i < aantalSlots; i++) {
        const slotStartTotalMinutes = startHour * 60 + i * slotDuration;
        const slotEndTotalMinutes = slotStartTotalMinutes + slotDuration;
        const row = document.createElement("tr");

        const timeCell = document.createElement("td");
        timeCell.classList.add("tijdkolom");
        timeCell.textContent = formatHour(Math.floor(slotStartTotalMinutes / 60), slotStartTotalMinutes % 60) + " - " + 
                                formatHour(Math.floor(slotEndTotalMinutes / 60), slotEndTotalMinutes % 60);
        row.appendChild(timeCell);

        days.forEach((dag, index) => {
            const dayCell = document.createElement("td");
            const eventForSlot = events.find(e => {
                if (!e.start) return false;
                const isoStart = convertICalDateToISO(e.start);
                const eventDate = new Date(isoStart);
                const eventTotalMinutes = eventDate.getHours() * 60 + eventDate.getMinutes();
                return eventTotalMinutes >= slotStartTotalMinutes && eventTotalMinutes < slotEndTotalMinutes && eventDate.getDay() === index + 1;
            });

            if (eventForSlot) {
                const eventText = `${eventForSlot.subject} ${eventForSlot.classNumber} ${eventForSlot.additionalInfo}`;
                dayCell.textContent = eventText;
                dayCell.classList.add("event-cell");

                if (notesEnabled) {
                    const noteInput = document.createElement("input");
                    noteInput.type = "text";
                    noteInput.placeholder = "Voeg notitie toe...";
                    noteInput.value = getSavedNote(eventText) || "";
                    noteInput.addEventListener("input", () => saveNote(eventText, noteInput.value));
                    dayCell.appendChild(noteInput);
                }
            } else {
                dayCell.textContent = "";
                dayCell.classList.add("empty-slot");
            }
            row.appendChild(dayCell);
        });
        eventTable.appendChild(row);
    }
}

function saveNote(eventText, note) {
    let notes = JSON.parse(localStorage.getItem("lessonNotes")) || {};
    notes[eventText] = note;
    localStorage.setItem("lessonNotes", JSON.stringify(notes));
}

function getSavedNote(eventText) {
    let notes = JSON.parse(localStorage.getItem("lessonNotes")) || {};
    return notes[eventText] || "";
}

function toggleNotesVisibility() {
    const currentState = getNotesVisibility();
    localStorage.setItem("notesEnabled", JSON.stringify(!currentState));
    location.reload();
}

function getNotesVisibility() {
    return JSON.parse(localStorage.getItem("notesEnabled")) ?? true;
}

function clearNotesOnNewWeek() {
    const currentWeek = getCurrentWeekNumber();
    const savedWeek = JSON.parse(localStorage.getItem("lastWeekSaved")) || 0;
    if (currentWeek !== savedWeek) {
        localStorage.removeItem("lessonNotes");
        localStorage.setItem("lastWeekSaved", JSON.stringify(currentWeek));
    }
}

function getCurrentWeekNumber() {
    const now = new Date();
    const startOfYear = new Date(now.getFullYear(), 0, 1);
    const pastDaysOfYear = (now - startOfYear) / 86400000;
    return Math.ceil((pastDaysOfYear + startOfYear.getDay() + 1) / 7);
}
document.addEventListener("DOMContentLoaded", () => {
  // Toon de pop-up om de code in te vullen
  document.getElementById("popup").style.display = "flex";

  // Haal de iCalendar-codes op van een JSON-bestand
  fetch('calendarCodes.json')
    .then(response => response.json())
    .then(calendarTokens => {
      document.getElementById("submitCode").addEventListener("click", () => {
        const calendarCode = document.getElementById("calendarCode").value.trim();
        if (calendarTokens[calendarCode]) {
          const icalURL = calendarTokens[calendarCode];
          loadICalendarFromURL(icalURL);

          // Verberg de pop-up na invoer
          document.getElementById("popup").style.display = "none";
        } else {
          alert("Ongeldige code.");
        }
      });
    })
    .catch(error => console.error("Fout bij het laden van de kalendercodes:", error));
});


// ... (rest of the code)

// Counter.html code
document.addEventListener('DOMContentLoaded', () => {
  const deviceUsageData = JSON.parse(localStorage.getItem('deviceUsageData')) || {};

  const counterList = document.createElement('ul');
  for (const device in deviceUsageData) {
    const listItem = document.createElement('li');
    listItem.textContent = `${device}: ${deviceUsageData[device]} keer bezocht`;
    counterList.appendChild(listItem);
  }

  document.body.appendChild(counterList);
});

// ... (rest of the code)