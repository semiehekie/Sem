<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AK Notities</title>
</head>
<body>
    <h1>AK Notities</h1>
    <div id="notities-container">
        <?php
            $map = "ak/"; // Zorg dat deze map bestaat!
            $bestanden = glob($map . "*.txt"); // Zoek alle .txt bestanden

            if (!empty($bestanden)) {
                foreach ($bestanden as $bestand) {
                    echo "<h2>" . basename($bestand, ".txt") . "</h2>"; // Bestandsnaam zonder .txt
                    echo "<pre>" . htmlspecialchars(file_get_contents($bestand)) . "</pre>"; // Inhoud tonen
                }
            } else {
                echo "<p>Geen notities gevonden.</p>";
            }
        ?>
    </div>
</body>
</html>
