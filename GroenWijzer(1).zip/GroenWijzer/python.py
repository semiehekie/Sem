import requests
from bs4 import BeautifulSoup

# URL van de Somtoday pagina voor cijfers (vervang deze door de juiste URL)
url = 'https://leerling.somtoday.nl/cijfers'

# Headers instellen zodat het script zich voordoet als een echte browser
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
}

# Haal de HTML op van de pagina
response = requests.get(url, headers=headers)

# Controleer of de request succesvol was
if response.status_code == 200:
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Zoek naar de specifieke HTML-elementen die de cijfers bevatten
    # Dit is een voorbeeld, je moet de juiste tags en klassen vinden op basis van de pagina
    cijfers = soup.find_all('div', class_='cijfer-class')  # Pas dit aan naar de juiste tag of class
    
    # Print de cijfers
    for cijfer in cijfers:
        print(cijfer.text)
else:
    print(f"Error: {response.status_code}")
