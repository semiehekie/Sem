import { initializeApp } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-auth.js";
import { getFirestore, doc, setDoc, getDoc } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-firestore.js";

// 🔥 Firebase Config
const firebaseConfig = {
    apiKey: "AIzaSyB3t27Ywn2Q7uRXM2167sHIv7oK0nQJyXY",
    authDomain: "weekrooster-c6fe7.firebaseapp.com",
    projectId: "weekrooster-c6fe7",
    storageBucket: "weekrooster-c6fe7.firebasestorage.app",
    messagingSenderId: "455652408779",
    appId: "1:455652408779:web:53bd5691d1952d73a68a4e",
    measurementId: "G-BWF7FCELZ8"
  };

// 🔥 Initialiseer Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.getElementById("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    try {
        let userCredential;
        try {
            userCredential = await signInWithEmailAndPassword(auth, email, password);
        } catch (error) {
            userCredential = await createUserWithEmailAndPassword(auth, email, password);
            await setDoc(doc(db, "users", userCredential.user.uid), { icsLink: "" });
        }
        localStorage.setItem("userId", userCredential.user.uid);
        window.location.href = "index.html";  // Ga naar roosterpagina
    } catch (error) {
        alert("Fout: " + error.message);
    }
});

onAuthStateChanged(auth, (user) => {
    if (user) {
        localStorage.setItem("userId", user.uid);
        window.location.href = "index.html";
    }
});
