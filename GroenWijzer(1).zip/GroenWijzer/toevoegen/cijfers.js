// Haal de cijfers op van de server
fetch('/cijfers')
    .then(response => response.json())
    .then(cijfers => {
        const cijfersList = document.getElementById('cijfers');
        cijfers.forEach(cijfer => {
            const listItem = document.createElement('li');
            listItem.textContent = cijfer;
            cijfersList.appendChild(listItem);
        });
    })
    .catch(error => console.error('Error:', error));
