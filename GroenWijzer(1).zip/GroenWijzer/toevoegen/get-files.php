<?php
// Pad naar de map 'ak'
$directory = 'ak/';

// Haal alle bestanden op in de map
$files = array_diff(scandir($directory), array('..', '.')); // Negeer '.' en '..'

// Geef de lijst van bestanden terug als JSON
echo json_encode(['files' => array_values($files)]);
?>
