const puppeteer = require('puppeteer');

async function getHomework() {
  const browser = await puppeteer.launch();
  const page = await browser.newPage();

  await page.goto('https://elo.somtoday.nl/home/homework');


  await page.waitForSelector('.homework-class'); 

 
  const homeworkData = await page.evaluate(() => {
    let homeworkItems = [];
    let items = document.querySelectorAll('.homework-class');

    items.forEach(item => {
      homeworkItems.push({
        subject: item.querySelector('.subject-class').innerText, 
        description: item.querySelector('.description-class').innerText,
        deadline: item.querySelector('.deadline-class').innerText,
      });
    });

    return homeworkItems;
  });

  await browser.close();

  
  console.log(homeworkData);
}

getHomework();
